import BlogSection from '../BlogSection'

export default function BlogSectionExample() {
  return <BlogSection />
}
