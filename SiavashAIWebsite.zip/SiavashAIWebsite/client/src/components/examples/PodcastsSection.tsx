import PodcastsSection from '../PodcastsSection'

export default function PodcastsSectionExample() {
  return <PodcastsSection />
}
