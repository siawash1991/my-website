import ConsultationSection from '../ConsultationSection'

export default function ConsultationSectionExample() {
  return <ConsultationSection />
}
