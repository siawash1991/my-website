import IdeasSection from '../IdeasSection'

export default function IdeasSectionExample() {
  return <IdeasSection />
}
